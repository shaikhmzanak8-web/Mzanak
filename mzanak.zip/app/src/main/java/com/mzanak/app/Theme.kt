package com.mzanak.app

import android.content.SharedPreferences
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** All adjustable "liquid glass" settings, saved on the device. */
class GlassSettings(private val prefs: SharedPreferences) {
    var hue by mutableFloatStateOf(prefs.getFloat("hue", 215f))
    var sat by mutableFloatStateOf(prefs.getFloat("sat", 0.38f))
    var opacity by mutableFloatStateOf(prefs.getFloat("opacity", 0.5f))
    var corner by mutableFloatStateOf(prefs.getFloat("corner", 26f))
    var shine by mutableFloatStateOf(prefs.getFloat("shine", 0.7f))
    var glow by mutableFloatStateOf(prefs.getFloat("glow", 0.6f))
    var mode by mutableIntStateOf(prefs.getInt("mode", 0)) // 0 system, 1 light, 2 dark

    fun save() {
        prefs.edit()
            .putFloat("hue", hue).putFloat("sat", sat).putFloat("opacity", opacity)
            .putFloat("corner", corner).putFloat("shine", shine).putFloat("glow", glow)
            .putInt("mode", mode).apply()
    }

    fun reset() {
        hue = 215f; sat = 0.38f; opacity = 0.5f; corner = 26f; shine = 0.7f; glow = 0.6f; mode = 0
        save()
    }

    fun accent(dark: Boolean): Color =
        Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), if (dark) 0.95f else 0.80f)

    fun shifted(dark: Boolean, delta: Float): Color =
        Color.hsv(((hue + delta) % 360f + 360f) % 360f, sat.coerceIn(0f, 1f), if (dark) 0.95f else 0.85f)
}

val LocalGlass = staticCompositionLocalOf<GlassSettings> { error("GlassSettings missing") }
val LocalDark = staticCompositionLocalOf { true }

@Composable
fun GlassSettings.isDark(): Boolean = when (mode) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun MzanakTheme(g: GlassSettings, content: @Composable () -> Unit) {
    val dark = g.isDark()
    val accent = g.accent(dark)
    val scheme = if (dark) darkColorScheme(
        primary = accent, onPrimary = Color(0xFF0B0E13), secondary = accent,
        background = Color(0xFF0B0E13), surface = Color(0xFF121722),
        onBackground = Color(0xFFE8ECF3), onSurface = Color(0xFFE8ECF3)
    ) else lightColorScheme(
        primary = accent, onPrimary = Color.White, secondary = accent,
        background = Color(0xFFF4F6FA), surface = Color.White,
        onBackground = Color(0xFF181C24), onSurface = Color(0xFF181C24)
    )
    CompositionLocalProvider(
        LocalGlass provides g,
        LocalDark provides dark,
        LocalContentColor provides scheme.onBackground
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** The liquid-glass surface: translucent tinted gradient + bright rim + top highlight. */
@Composable
fun Modifier.glass(radius: Dp? = null, strength: Float = 1f): Modifier {
    val g = LocalGlass.current
    val dark = LocalDark.current
    val accent = g.accent(dark)
    val rad = radius ?: g.corner.dp
    val shape = RoundedCornerShape(rad)
    val a = (g.opacity * strength).coerceIn(0f, 1f)
    val shine = g.shine
    val top = Color.White.copy(alpha = (if (dark) a * 0.28f else a * 0.9f).coerceIn(0f, 1f))
    val bottom = accent.copy(alpha = (if (dark) a * 0.18f else a * 0.35f).coerceIn(0f, 1f))
    val rim = Brush.linearGradient(
        listOf(
            Color.White.copy(alpha = ((if (dark) 0.55f else 0.95f) * shine).coerceIn(0f, 1f)),
            Color.White.copy(alpha = (0.06f * shine).coerceIn(0f, 1f)),
            accent.copy(alpha = (0.4f * shine).coerceIn(0f, 1f))
        )
    )
    return this
        .clip(shape)
        .background(Brush.linearGradient(listOf(top, bottom)))
        .drawBehind {
            val r = rad.toPx()
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = (0.16f * shine).coerceIn(0f, 1f)), Color.Transparent),
                    startY = 0f, endY = size.height * 0.55f
                ),
                cornerRadius = CornerRadius(r, r)
            )
        }
        .border(1.dp, rim, shape)
}

/** Slowly drifting colour glows behind everything, so the glass has something to refract. */
@Composable
fun GlassBackground() {
    val g = LocalGlass.current
    val dark = LocalDark.current
    val c1 = g.accent(dark)
    val c2 = g.shifted(dark, 45f)
    val c3 = g.shifted(dark, -45f)
    val t = rememberInfiniteTransition(label = "bg")
    val p1 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "p1")
    val p2 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse), label = "p2")
    val p3 by t.animateFloat(0f, 1f, infiniteRepeatable(tween(29000, easing = LinearEasing), RepeatMode.Reverse), label = "p3")
    val base = if (dark) listOf(Color(0xFF0A0D12), Color(0xFF121722)) else listOf(Color(0xFFF6F8FB), Color(0xFFE8ECF4))
    val glow = g.glow
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(base))
        val w = size.width
        val h = size.height
        val r = maxOf(w, h)
        fun blob(c: Color, cx: Float, cy: Float, rad: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(c.copy(alpha = (0.55f * glow).coerceIn(0f, 1f)), Color.Transparent),
                    center = Offset(cx, cy), radius = rad
                ),
                radius = rad, center = Offset(cx, cy)
            )
        }
        blob(c1, w * (0.1f + 0.7f * p1), h * (0.08f + 0.25f * p2), r * 0.65f)
        blob(c2, w * (0.95f - 0.7f * p2), h * (0.5f + 0.2f * p3), r * 0.6f)
        blob(c3, w * (0.1f + 0.6f * p3), h * (0.95f - 0.3f * p1), r * 0.55f)
    }
}
