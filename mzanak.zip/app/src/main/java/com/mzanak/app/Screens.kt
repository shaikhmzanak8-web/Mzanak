package com.mzanak.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ───────────────────────── permissions ─────────────────────────

fun hasMediaAccess(ctx: Context): Boolean {
    fun ok(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return if (Build.VERSION.SDK_INT >= 33)
        ok(Manifest.permission.READ_MEDIA_IMAGES) || ok(Manifest.permission.READ_MEDIA_VIDEO) || ok(Manifest.permission.READ_MEDIA_AUDIO)
    else ok(Manifest.permission.READ_EXTERNAL_STORAGE)
}

fun mediaPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33)
        arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS
        )
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

// ───────────────────────── root ─────────────────────────

@Composable
fun MzanakApp() {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val dark = LocalDark.current
    val lib = remember { Library() }
    val scope = rememberCoroutineScope()

    var granted by remember { mutableStateOf(hasMediaAccess(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasMediaAccess(ctx)
        if (granted) scope.launch { lib.refresh(ctx) }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                granted = hasMediaAccess(ctx)
                if (granted) scope.launch { lib.refresh(ctx) }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val ic = WindowCompat.getInsetsController(w, view)
            ic.isAppearanceLightStatusBars = !dark
            ic.isAppearanceLightNavigationBars = !dark
        }
    }

    var tab by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var imageIndex by remember { mutableStateOf<Int?>(null) }
    var showVideo by remember { mutableStateOf(false) }
    var showPlayer by remember { mutableStateOf(false) }

    BackHandler(enabled = tab != 0 && !showSettings) { tab = 0 }
    BackHandler(enabled = showSettings) { showSettings = false }

    val open: (MediaFile) -> Unit = { f ->
        when (f.kind) {
            Kind.IMAGE -> imageIndex = lib.images.indexOf(f).coerceAtLeast(0)
            Kind.VIDEO -> {
                PlayerHub.play(lib.videos, lib.videos.indexOf(f))
                showVideo = true
            }
            Kind.AUDIO -> PlayerHub.play(lib.audios, lib.audios.indexOf(f))
        }
    }

    Box(Modifier.fillMaxSize()) {
        GlassBackground()
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).statusBarsPadding()) {
                when {
                    !granted -> PermissionScreen(
                        onAllow = { launcher.launch(mediaPermissions()) },
                        onSettings = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                            )
                        }
                    )
                    showSettings -> SettingsScreen { showSettings = false }
                    else -> when (tab) {
                        0 -> BrowseScreen(lib, query, { query = it }, { tab = it }, open) { showSettings = true }
                        1 -> MediaGridScreen("Photos", lib.images, lib.loaded, open)
                        2 -> MediaGridScreen("Videos", lib.videos, lib.loaded, open)
                        else -> MusicScreen(lib, lib.loaded)
                    }
                }
            }
            if (PlayerHub.hasMedia && granted) {
                MiniPlayer { if (PlayerHub.isVideo) showVideo = true else showPlayer = true }
            }
            if (granted) BottomBar(tab) { tab = it; showSettings = false }
            else Spacer(Modifier.navigationBarsPadding())
        }

        imageIndex?.let { idx -> ImageViewer(lib.images, idx) { imageIndex = null } }
        AnimatedVisibility(showVideo, enter = fadeIn(), exit = fadeOut()) { VideoOverlay { showVideo = false } }
        AnimatedVisibility(
            showPlayer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) { MusicPlayer { showPlayer = false } }
    }
}

// ───────────────────────── shared pieces ─────────────────────────

@Composable
fun Thumb(uri: Uri, modifier: Modifier = Modifier, size: Int = 256, icon: ImageVector = Icons.Rounded.Image) {
    val app = LocalContext.current.applicationContext
    val bmp by produceState(initialValue = Thumbs.peek(uri, size), uri, size) {
        if (value == null) value = withContext(Dispatchers.IO) { Thumbs.load(app, uri, size) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier.background(Color.White.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(24.dp), tint = LocalContentColor.current.copy(alpha = 0.45f))
        }
    }
}

@Composable
fun dim(): Color = LocalContentColor.current.copy(alpha = 0.62f)

fun iconFor(k: Kind): ImageVector = when (k) {
    Kind.IMAGE -> Icons.Rounded.Image
    Kind.VIDEO -> Icons.Rounded.Movie
    Kind.AUDIO -> Icons.Rounded.MusicNote
}

@Composable
fun GlassIconButton(icon: ImageVector, onClick: () -> Unit, size: Dp = 44.dp, tint: Color = LocalContentColor.current) {
    Box(
        Modifier.size(size).glass(radius = size / 2).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, Modifier.size(size * 0.5f), tint = tint) }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = dim())
        }
        trailing()
    }
}

@Composable
fun EmptyState(loaded: Boolean, text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (!loaded) CircularProgressIndicator() else Text(text, color = dim())
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val g = LocalGlass.current
    val acc = g.accent(LocalDark.current)
    val items = remember {
        listOf(
            "Browse" to Icons.Rounded.FolderOpen,
            "Photos" to Icons.Rounded.Image,
            "Videos" to Icons.Rounded.VideoLibrary,
            "Music" to Icons.Rounded.LibraryMusic
        )
    }
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).navigationBarsPadding()
            .fillMaxWidth().glass(radius = 30.dp, strength = 1.2f).padding(6.dp)
    ) {
        items.forEachIndexed { i, (label, icon) ->
            val sel = i == tab
            val c = if (sel) acc else LocalContentColor.current.copy(alpha = 0.7f)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                    .background(if (sel) acc.copy(alpha = 0.25f) else Color.Transparent)
                    .clickable { onTab(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, label, Modifier.size(24.dp), tint = c)
                Text(label, fontSize = 11.sp, color = c)
            }
        }
    }
}

@Composable
fun MiniPlayer(onOpen: () -> Unit) {
    val c = PlayerHub.controller
    Row(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().glass(radius = 22.dp, strength = 1.2f)
            .clickable(onClick = onOpen).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(Uri.parse(PlayerHub.mediaId), Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)), 128, Icons.Rounded.MusicNote)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(PlayerHub.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (PlayerHub.subtitle.isNotEmpty())
                Text(PlayerHub.subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = dim())
        }
        IconButton({ if (PlayerHub.isPlaying) c?.pause() else c?.play() }) {
            Icon(if (PlayerHub.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
        }
        IconButton({ c?.seekToNext() }) { Icon(Icons.Rounded.SkipNext, null) }
        IconButton({ PlayerHub.stopAll() }) { Icon(Icons.Rounded.Close, null) }
    }
    Spacer(Modifier.height(4.dp))
}

@Composable
fun PermissionScreen(onAllow: () -> Unit, onSettings: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth().glass(radius = 32.dp, strength = 1.3f).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Rounded.FolderOpen, null, Modifier.size(48.dp), tint = LocalGlass.current.accent(LocalDark.current))
            Spacer(Modifier.height(12.dp))
            Text("Welcome to Mzanak", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Mzanak needs access to the photos, videos and music on your device. Everything stays on your phone — the app is fully offline.",
                color = dim(), fontSize = 14.sp
            )
            Spacer(Modifier.height(20.dp))
            Button(onAllow, shape = RoundedCornerShape(50)) { Text("Allow access") }
            TextButton(onSettings) { Text("Open app settings") }
        }
    }
}

// ───────────────────────── browse ─────────────────────────

@Composable
fun BrowseScreen(
    lib: Library, query: String, onQuery: (String) -> Unit, onTab: (Int) -> Unit,
    onOpen: (MediaFile) -> Unit, onTheme: () -> Unit
) {
    val acc = LocalGlass.current.accent(LocalDark.current)
    val list = remember(lib.images, lib.videos, lib.audios, query) {
        val q = query.trim()
        val all = ArrayList<MediaFile>(lib.images.size + lib.videos.size + lib.audios.size)
        all.addAll(lib.images); all.addAll(lib.videos); all.addAll(lib.audios)
        val f = if (q.isEmpty()) all else all.filter {
            it.name.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
        }
        f.sortedByDescending { it.added }.take(if (q.isEmpty()) 30 else 300)
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "head", contentType = "head") {
            Column {
                ScreenHeader("Mzanak", "Your media, offline") {
                    GlassIconButton(Icons.Rounded.Palette, onTheme)
                }
                TextField(
                    value = query, onValueChange = onQuery, singleLine = true,
                    placeholder = { Text("Search your files") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton({ onQuery("") }) { Icon(Icons.Rounded.Close, null) }
                    },
                    shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier.fillMaxWidth().glass(radius = 28.dp)
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryCard("Photos", lib.images.size, Icons.Rounded.Image, acc, Modifier.weight(1f)) { onTab(1) }
                    CategoryCard("Videos", lib.videos.size, Icons.Rounded.VideoLibrary, acc, Modifier.weight(1f)) { onTab(2) }
                    CategoryCard("Music", lib.audios.size, Icons.Rounded.LibraryMusic, acc, Modifier.weight(1f)) { onTab(3) }
                }
                Spacer(Modifier.height(18.dp))
                Text(if (query.isBlank()) "Recent files" else "Results", fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
        if (list.isEmpty()) {
            item(key = "empty") {
                Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                    if (!lib.loaded) CircularProgressIndicator() else Text("Nothing here yet", color = dim())
                }
            }
        }
        items(list, key = { "${it.kind}${it.id}" }, contentType = { "row" }) { f ->
            FileRow(f) { onOpen(f) }
        }
    }
}

@Composable
fun CategoryCard(label: String, count: Int, icon: ImageVector, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.glass(radius = 22.dp).clickable(onClick = onClick).padding(14.dp)) {
        Icon(icon, null, Modifier.size(28.dp), tint = tint)
        Spacer(Modifier.height(8.dp))
        Text(label, fontWeight = FontWeight.Medium, fontSize = 15.sp)
        Text("$count items", fontSize = 12.sp, color = dim())
    }
}

@Composable
fun FileRow(f: MediaFile, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(radius = 18.dp, strength = 0.7f).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(f.uri, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), 160, iconFor(f.kind))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text("${fmtSize(f.size)} • ${fmtDate(f.added)}", fontSize = 12.sp, color = dim())
        }
        if (f.kind != Kind.IMAGE) Text(fmtTime(f.duration), fontSize = 12.sp, color = dim())
    }
}

// ───────────────────────── photos & videos ─────────────────────────

@Composable
fun MediaGridScreen(title: String, files: List<MediaFile>, loaded: Boolean, onOpen: (MediaFile) -> Unit) {
    val groups = remember(files) { files.groupBy { monthLabel(it.added) }.entries.toList() }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, "${files.size} items")
        if (files.isEmpty()) {
            EmptyState(loaded, "No ${title.lowercase()} found")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                for (entry in groups) {
                    item(key = "h" + entry.key, span = { GridItemSpan(maxLineSpan) }, contentType = "h") {
                        Text(
                            entry.key, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = dim(),
                            modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 4.dp)
                        )
                    }
                    items(entry.value, key = { it.id }, contentType = { "cell" }) { f ->
                        Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).clickable { onOpen(f) }) {
                            Thumb(f.uri, Modifier.fillMaxSize(), 256, iconFor(f.kind))
                            if (f.kind == Kind.VIDEO) {
                                Text(
                                    fmtTime(f.duration), fontSize = 11.sp, color = Color.White,
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
                                        .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── music ─────────────────────────

@Composable
fun MusicScreen(lib: Library, loaded: Boolean) {
    val songs = lib.audios
    val acc = LocalGlass.current.accent(LocalDark.current)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Music", "${songs.size} songs")
        if (songs.isEmpty()) {
            EmptyState(loaded, "No music found")
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item(key = "actions", contentType = "actions") {
                    Row(Modifier.padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button({ PlayerHub.controller?.shuffleModeEnabled = false; PlayerHub.play(songs, 0) }, shape = RoundedCornerShape(50)) {
                            Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Play all")
                        }
                        Box(
                            Modifier.glass(radius = 50.dp).clickable { PlayerHub.playShuffled(songs) }
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Shuffle, null, tint = acc); Spacer(Modifier.width(6.dp)); Text("Shuffle")
                            }
                        }
                    }
                }
                items(songs, key = { it.id }, contentType = { "song" }) { f ->
                    SongRow(f, PlayerHub.mediaId == f.uri.toString()) {
                        PlayerHub.play(songs, songs.indexOf(f))
                    }
                }
            }
        }
    }
}

@Composable
fun SongRow(f: MediaFile, current: Boolean, onClick: () -> Unit) {
    val acc = LocalGlass.current.accent(LocalDark.current)
    Row(
        Modifier.fillMaxWidth().glass(radius = 18.dp, strength = if (current) 1.3f else 0.6f)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(f.uri, Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), 160, Icons.Rounded.MusicNote)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                f.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                color = if (current) acc else LocalContentColor.current
            )
            Text("${f.artist} • ${f.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = dim())
        }
        Text(fmtTime(f.duration), fontSize = 12.sp, color = dim())
    }
}

@Composable
fun MusicPlayer(onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val c = PlayerHub.controller
    val acc = LocalGlass.current.accent(LocalDark.current)
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(c) {
        while (true) {
            if (c != null) {
                pos = c.currentPosition
                dur = c.duration.coerceAtLeast(0L)
            }
            delay(300)
        }
    }
    Box(Modifier.fillMaxSize()) {
        GlassBackground()
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton(Icons.Rounded.KeyboardArrowDown, onClose)
                Spacer(Modifier.weight(1f))
                Text("Now playing", fontSize = 14.sp, color = dim())
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(44.dp))
            }
            Spacer(Modifier.height(24.dp))
            Box(Modifier.fillMaxWidth().aspectRatio(1f).glass(radius = 32.dp, strength = 1.2f).padding(10.dp)) {
                Thumb(
                    Uri.parse(PlayerHub.mediaId), Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),
                    700, Icons.Rounded.MusicNote
                )
            }
            Spacer(Modifier.height(22.dp))
            Text(PlayerHub.title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(PlayerHub.subtitle, fontSize = 15.sp, color = dim(), maxLines = 1)
            Spacer(Modifier.weight(1f))
            val shown = dragging ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            Slider(
                value = shown,
                onValueChange = { dragging = it },
                onValueChangeFinished = {
                    dragging?.let { c?.seekTo((it * dur).toLong()) }
                    dragging = null
                }
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                Text(fmtTime(((dragging ?: shown) * dur).toLong()), fontSize = 12.sp, color = dim())
                Spacer(Modifier.weight(1f))
                Text(fmtTime(dur), fontSize = 12.sp, color = dim())
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton(Icons.Rounded.Shuffle, { PlayerHub.toggleShuffle() }, 48.dp, if (PlayerHub.shuffle) acc else LocalContentColor.current.copy(alpha = 0.6f))
                GlassIconButton(Icons.Rounded.SkipPrevious, { c?.seekToPrevious() }, 56.dp)
                Box(
                    Modifier.size(76.dp).glass(radius = 38.dp, strength = 1.8f)
                        .clickable { if (PlayerHub.isPlaying) c?.pause() else c?.play() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (PlayerHub.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(38.dp), tint = acc)
                }
                GlassIconButton(Icons.Rounded.SkipNext, { c?.seekToNext() }, 56.dp)
                GlassIconButton(
                    if (PlayerHub.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    { PlayerHub.cycleRepeat() }, 48.dp,
                    if (PlayerHub.repeatMode != Player.REPEAT_MODE_OFF) acc else LocalContentColor.current.copy(alpha = 0.6f)
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ───────────────────────── viewers ─────────────────────────

@Composable
fun ImageViewer(images: List<MediaFile>, start: Int, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    if (images.isEmpty()) return
    val pager = rememberPagerState(initialPage = start.coerceIn(0, images.lastIndex)) { images.size }
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(
                state = pager, key = { images[it].id }, beyondViewportPageCount = 1,
                modifier = Modifier.fillMaxSize()
            ) { page -> ZoomableImage(images[page].uri) }
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, onClose)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.glass(radius = 16.dp).padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text(images[pager.currentPage].name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${pager.currentPage + 1} / ${images.size}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun ZoomableImage(uri: Uri) {
    val app = LocalContext.current.applicationContext
    val bmp by produceState<ImageBitmap?>(null, uri) { value = withContext(Dispatchers.IO) { decodeFull(app, uri) } }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    scale = if (scale > 1f) 1f else 2.5f
                    offset = Offset.Zero
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.size > 1 || scale > 1f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale <= 1f) Offset.Zero else offset + pan
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b == null) CircularProgressIndicator()
        else Image(
            bitmap = b, contentDescription = null, contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y
            }
        )
    }
}

@Composable
fun VideoOverlay(onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val c = PlayerHub.controller
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (c != null) {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = c
                            useController = true
                            keepScreenOn = true
                        }
                    },
                    update = { it.player = c },
                    onRelease = { it.player = null },
                    modifier = Modifier.fillMaxSize()
                )
            }
            Box(Modifier.statusBarsPadding().padding(12.dp)) {
                GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, onClose)
            }
        }
    }
}

// ───────────────────────── settings ─────────────────────────

@Composable
fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().glass(radius = 24.dp).padding(16.dp), content = content)
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Column {
        Row {
            Text(label, Modifier.weight(1f), fontSize = 14.sp)
            Text("${((value - range.start) / (range.endInclusive - range.start) * 100).toInt()}%", fontSize = 13.sp, color = dim())
        }
        Slider(value, onChange, valueRange = range, onValueChangeFinished = onDone)
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val g = LocalGlass.current
    val dark = LocalDark.current
    val acc = g.accent(dark)
    val hues = remember { listOf(215f, 265f, 330f, 20f, 45f, 150f, 190f) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, onBack)
            Spacer(Modifier.width(14.dp))
            Text("Liquid glass theme", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        GlassCard {
            Text("Appearance", fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                    val sel = g.mode == i
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (sel) acc.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.08f))
                            .clickable { g.mode = i; g.save() }.padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(label, color = if (sel) acc else LocalContentColor.current) }
                }
            }
        }
        GlassCard {
            Text("Accent colour", fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                hues.forEach { h ->
                    val sel = kotlin.math.abs(g.hue - h) < 1f
                    Box(
                        Modifier.size(34.dp).clip(CircleShape)
                            .background(Color.hsv(h, maxOf(g.sat, 0.5f), 0.9f))
                            .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.White.copy(alpha = 0.4f), CircleShape)
                            .clickable { g.hue = h; g.save() }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            SliderRow("Custom hue", g.hue, 0f..360f, { g.hue = it }, { g.save() })
            SliderRow("Colour intensity", g.sat, 0f..1f, { g.sat = it }, { g.save() })
        }
        GlassCard {
            Text("Glass", fontWeight = FontWeight.Medium)
            SliderRow("Opacity", g.opacity, 0.05f..1f, { g.opacity = it }, { g.save() })
            SliderRow("Roundness", g.corner, 6f..40f, { g.corner = it }, { g.save() })
            SliderRow("Shine", g.shine, 0f..1f, { g.shine = it }, { g.save() })
            SliderRow("Background glow", g.glow, 0f..1f, { g.glow = it }, { g.save() })
        }
        TextButton({ g.reset() }, Modifier.align(Alignment.CenterHorizontally)) { Text("Reset to default") }
        Spacer(Modifier.height(12.dp))
    }
}
