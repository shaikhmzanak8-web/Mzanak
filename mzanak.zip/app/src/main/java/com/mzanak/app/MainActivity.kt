package com.mzanak.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val glass = GlassSettings(getSharedPreferences("mzanak_theme", MODE_PRIVATE))
        PlayerHub.connect(applicationContext)
        setContent {
            MzanakTheme(glass) { MzanakApp() }
        }
    }
}
