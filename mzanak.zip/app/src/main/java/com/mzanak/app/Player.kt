package com.mzanak.app

import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import kotlin.random.Random

/** Runs the real player inside a foreground service => music/video audio keeps playing in the background. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}

/** UI-side handle to the playback service. */
object PlayerHub {
    var controller by mutableStateOf<MediaController?>(null)
    var hasMedia by mutableStateOf(false)
    var isPlaying by mutableStateOf(false)
    var title by mutableStateOf("")
    var subtitle by mutableStateOf("")
    var mediaId by mutableStateOf("")
    var isVideo by mutableStateOf(false)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    private var started = false

    fun connect(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = sync(player)
                })
                sync(c)
            } catch (e: Exception) {
                started = false
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun sync(p: Player) {
        val md = p.mediaMetadata
        hasMedia = p.mediaItemCount > 0
        isPlaying = p.isPlaying
        title = md.title?.toString() ?: ""
        subtitle = md.artist?.toString() ?: ""
        mediaId = p.currentMediaItem?.mediaId ?: ""
        isVideo = md.extras?.getString("kind") == "VIDEO"
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
    }

    private fun MediaFile.toItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(uri.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(if (kind == Kind.AUDIO) artist else null)
                    .setAlbumTitle(if (kind == Kind.AUDIO) album else null)
                    .setExtras(Bundle().apply { putString("kind", kind.name) })
                    .build()
            )
            .build()

    fun play(list: List<MediaFile>, index: Int) {
        val c = controller ?: return
        if (index !in list.indices) return
        val target = list[index].uri.toString()
        if (c.currentMediaItem?.mediaId == target && c.mediaItemCount == list.size) {
            c.play()
            return
        }
        c.setMediaItems(list.map { it.toItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playShuffled(list: List<MediaFile>) {
        val c = controller ?: return
        if (list.isEmpty()) return
        c.shuffleModeEnabled = true
        c.setMediaItems(list.map { it.toItem() }, Random.nextInt(list.size), 0L)
        c.prepare()
        c.play()
    }

    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun stopAll() {
        controller?.let { it.stop(); it.clearMediaItems() }
    }
}
