package com.mzanak.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

enum class Kind { IMAGE, VIDEO, AUDIO }

data class MediaFile(
    val id: Long,
    val uri: Uri,
    val name: String,
    val title: String,
    val size: Long,
    val added: Long,
    val duration: Long,
    val artist: String,
    val album: String,
    val kind: Kind
)

object MediaRepo {
    private fun clean(s: String?, fallback: String): String =
        if (s.isNullOrBlank() || s == "<unknown>") fallback else s

    fun load(ctx: Context, kind: Kind): List<MediaFile> {
        val collection = when (kind) {
            Kind.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            Kind.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            Kind.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val proj = mutableListOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        if (kind != Kind.IMAGE) proj += MediaStore.MediaColumns.DURATION
        if (kind == Kind.AUDIO) {
            proj += MediaStore.Audio.Media.TITLE
            proj += MediaStore.Audio.Media.ARTIST
            proj += MediaStore.Audio.Media.ALBUM
        }
        val sel = if (kind == Kind.AUDIO)
            "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND ${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND ${MediaStore.Audio.Media.IS_ALARM} = 0"
        else null

        val out = ArrayList<MediaFile>()
        ctx.contentResolver.query(
            collection, proj.toTypedArray(), sel, null,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iDur = if (kind != Kind.IMAGE) c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION) else -1
            val iTitle = if (kind == Kind.AUDIO) c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE) else -1
            val iArtist = if (kind == Kind.AUDIO) c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST) else -1
            val iAlbum = if (kind == Kind.AUDIO) c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM) else -1
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val name = c.getString(iName) ?: "Unknown"
                val plain = name.substringBeforeLast('.')
                val title = if (iTitle >= 0) clean(c.getString(iTitle), plain) else plain
                out.add(
                    MediaFile(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id),
                        name = name,
                        title = title,
                        size = c.getLong(iSize),
                        added = c.getLong(iAdded),
                        duration = if (iDur >= 0) c.getLong(iDur) else 0L,
                        artist = if (iArtist >= 0) clean(c.getString(iArtist), "Unknown artist") else "",
                        album = if (iAlbum >= 0) clean(c.getString(iAlbum), "Unknown album") else "",
                        kind = kind
                    )
                )
            }
        }
        return out
    }
}

class Library {
    var images by mutableStateOf<List<MediaFile>>(emptyList())
    var videos by mutableStateOf<List<MediaFile>>(emptyList())
    var audios by mutableStateOf<List<MediaFile>>(emptyList())
    var loaded by mutableStateOf(false)

    private fun safe(ctx: Context, kind: Kind): List<MediaFile> =
        try { MediaRepo.load(ctx, kind) } catch (e: Exception) { emptyList() }

    suspend fun refresh(ctx: Context) {
        val app = ctx.applicationContext
        val r = withContext(Dispatchers.IO) {
            Triple(safe(app, Kind.IMAGE), safe(app, Kind.VIDEO), safe(app, Kind.AUDIO))
        }
        images = r.first
        videos = r.second
        audios = r.third
        loaded = true
    }
}

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val failed = HashSet<String>()

    private fun key(uri: Uri, size: Int) = "$uri@$size"

    fun peek(uri: Uri, size: Int): ImageBitmap? = cache.get(key(uri, size))?.asImageBitmap()

    fun load(ctx: Context, uri: Uri, size: Int): ImageBitmap? {
        val k = key(uri, size)
        cache.get(k)?.let { return it.asImageBitmap() }
        synchronized(failed) { if (failed.contains(k)) return null }
        return try {
            val bm = ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
            cache.put(k, bm)
            bm.asImageBitmap()
        } catch (e: Throwable) {
            synchronized(failed) { failed.add(k) }
            null
        }
    }
}

fun decodeFull(ctx: Context, uri: Uri, max: Int = 2048): ImageBitmap? = try {
    val src = ImageDecoder.createSource(ctx.contentResolver, uri)
    ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val m = maxOf(info.size.width, info.size.height)
        if (m > max) {
            val s = m.toFloat() / max
            decoder.setTargetSize(
                (info.size.width / s).toInt().coerceAtLeast(1),
                (info.size.height / s).toInt().coerceAtLeast(1)
            )
        }
    }.asImageBitmap()
} catch (e: Throwable) {
    null
}

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtSize(b: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < 3) { v /= 1024; i++ }
    return if (i == 0) "$b B" else "%.1f %s".format(v, units[i])
}

private val dateFmt = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withZone(ZoneId.systemDefault())
private val monthFmt = DateTimeFormatter.ofPattern("MMMM yyyy").withZone(ZoneId.systemDefault())

fun fmtDate(sec: Long): String = dateFmt.format(Instant.ofEpochSecond(sec))
fun monthLabel(sec: Long): String = monthFmt.format(Instant.ofEpochSecond(sec))
